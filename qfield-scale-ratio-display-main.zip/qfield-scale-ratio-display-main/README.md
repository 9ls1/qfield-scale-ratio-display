# Scale ratio display

Displays map scale as 1:scale text (e.g., 1:500) in the middle on the top of the screen.\
This makes it easier to do the mapping in e.g. scale 1:600–1:1000 (might be easier to interpret than the scale bar alone).\
You may turn it on/off.

Original icon number-1.png is created by [Rahul Kaklotar - Flaticon](https://www.flaticon.com/authors/rahul-kaklotar)

**How it looks**\
Scale ratio in center on top of screen – in addition to the scale bar in lower left corner (if activated in the Settings).\
<img width="320" alt="image" src="https://github.com/user-attachments/assets/1f689a4c-5c00-4a1a-b2f7-bd8487cf6e06" />  <img width="320" alt="image" src="https://github.com/user-attachments/assets/6d83a6df-b01d-43da-92a4-3b33fe494aab" />

## How to install
https://docs.qfield.org/how-to/advanced-how-tos/plugins/?h=plugin#application-plugins

QField > Settings, scroll down to User Interface and Manage plugins, click on the three dots and click on Install plugin from URL.

1. Copy/type in `https://github.com/9ls1/qfield-scale-ratio-display/releases/download/v2.0/qfield-scale-ratio-display-v2.0.zip` or
2. Click on the QR-code-icon to activate camera and take a picture of this QR-code\
<img width="320" height="320" alt="qr-code-url-v2 0" src="https://github.com/user-attachments/assets/6943cef4-92e0-46c0-9518-fd9e6c1f5ab4" />
