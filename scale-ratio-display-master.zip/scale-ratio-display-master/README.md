# Scale ratio display

Displays map scale as 1:scale text instead of scale bar (e.g., 1:500).

Original icon number-1.png is created by [Rahul Kaklotar - Flaticon](https://www.flaticon.com/authors/rahul-kaklotar)

[Learn more about creating GitLab projects.](https://docs.gitlab.com/ee/gitlab-basics/create-project.html)
